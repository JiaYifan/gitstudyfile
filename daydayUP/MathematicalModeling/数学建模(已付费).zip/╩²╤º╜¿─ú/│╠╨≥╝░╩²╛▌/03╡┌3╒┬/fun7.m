function f=fun7(x,s);
f=sum((x-0.5).^2);
