function f=fun5(x);
f=sin(x)+3;
