ezsurf(@(y,z) y.^2,50)
