Afun2=@(x) (x+1)*(x<1)+(1+1/x)*(x>=1);
fplot(Afun2,[-3,3])
