syms x
b=limit((sqrt(1+x^2)-1)/(1-cos(x)))
