syms n
f1=(2*n-1)/2^n;
s1=symsum(f1,n,1,inf)
